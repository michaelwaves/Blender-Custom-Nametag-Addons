bl_info = {
    "name":"Convex Nametag Generator",
    "author":"Michael",
    "version":(1, 0),
    "blender": (2, 80, 0),
    "location":"View3D",
    "description": "Makes convex nametags with custom font and scale",
    "warning": "",
    "doc_url": "",
    "tracker_url": "",
    "category": "Objects",
}
import bpy
from bpy.types import (Panel,Operator)
import os
from bpy.props import *

#blender needs to know what type of property to generate correct window
class SimpleOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "object.generate_convex_nametag"
    bl_label = "Convex Nametag Generator"
    bl_options = {"REGISTER","UNDO"}
    
    #create prooperties
    name_1 : StringProperty(
        name = "Name One",
        description = "the first name to transform",
        default = "",
        maxlen = 100
    )
    name_2 : StringProperty(
        name = "Name Two",
        description = "the second name to transform",
        default = "",
        maxlen = 100
    )
    name_3 : StringProperty(
        name = "Name Three",
        description = "the third name to transform",
        default = "",
        maxlen = 100
    )
    my_font : StringProperty(
        name = "font",
        description = "the font to use",
        default = "GILLUBCD.ttf",
        maxlen = 100
    )
    name_thickness : FloatProperty(
        name = "Name Thickness",
        description = "Height of name",
        default = 0.2,
        min = 0,
        max = 10
    )
    plane_thickness : FloatProperty(
        name = "Plate Thickness",
        description = "Height of plane",
        default = 0.1,
        min = 0,
        max = 10
    )
    my_scale : FloatProperty(
        name = "Scale",
        description = "Overall Size",
        default = 0.5,
        min = 0,
        max = 100
    )
    char_space : FloatProperty(
        name = "Line Spacing",
        description = "Space between characters",
        default = 1,
        min = 0,
        max = 100
    )
    def execute(self, context):
        
        #names = ['Rory','Ryan','Declan','Daniel','Alex','John','Simon','Mom','Dad']
        names = [self.name_1,self.name_2,self.name_3]
        #font = 'GILLUBCD.ttf'
        font = self.my_font


        def generate_nametag(name = "",
            f = "digital-7.TTF",
            n_thickness = self.name_thickness,
            p_thickness = self.plane_thickness, 
            scale = self.my_scale,
            char_space=self.char_space):
            #make sure we are in object mode
            obj =  bpy.context.active_object
            if obj:
                if bpy.context.mode == 'EDIT_TEXT' or 'EDIT_MESH':
                    bpy.ops.object.mode_set(mode="OBJECT")

            #convenience variables    
            font_path = "C:\Windows\Fonts\\"+f
            font = bpy.ops.font

            #add text
            bpy.ops.object.text_add()

            txt = bpy.context.active_object
            txt.data.space_character = char_space
            bpy.ops.object.mode_set(mode="EDIT")
            font.delete(type = 'PREVIOUS_WORD')

            #set text font
            myFont = bpy.data.fonts.load(font_path)
            txt.data.font = myFont

            #insert name we specified
            font.text_insert(text = name, accent = False)

            #go to object mode and convert to solid mesh
            bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.convert(target = "MESH")

            bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_all(action = "SELECT")
            bpy.ops.mesh.decimate(ratio = 1)
            bpy.ops.object.mode_set(mode="OBJECT")

            sld_mod = txt.modifiers.new('solifdify','SOLIDIFY')
            sld_mod.thickness = n_thickness
            bpy.ops.object.convert(target = "MESH")
            
            #scale text
            bpy.ops.transform.resize(value =(scale,scale,scale))
            bpy.ops.object.transform_apply(scale = True)

            #add plane
            bpy.ops.mesh.primitive_plane_add()
            plane = bpy.context.active_object

            #make plane same size as text
            plane.scale[0] = txt.dimensions.x/2
            plane.scale[1] = txt.dimensions.y/1.8

            #plane.dimensions.x = txt.dimensions.x
            #plane.dimensions.y = txt.dimensions.y

            #position plane
            plane.location[0]+=txt.dimensions.x/2+0.03
            plane.location[1]+=txt.dimensions.y/2
            plane.location[2]-=n_thickness*scale

            sld_mod_plane = plane.modifiers.new('solidify','SOLIDIFY')
            sld_mod_plane.thickness = p_thickness
            bool = bpy.ops.object.convert(target = 'MESH')

            #join objects
            bool = plane.modifiers.new('bool','BOOLEAN')
            bool.object = txt
            bool.operation = 'UNION'
            bool.solver = 'EXACT'
            bpy.ops.object.convert(target = 'MESH')

            #cleanup boolean remains
            plane.select_set(False)
            txt.select_set(True)
            bpy.ops.object.delete(confirm=False)

            #export
            dir = r"C:\Users\micha\Documents\Blender Files\Nametags\stl exports\\"
            filename = name
            path = dir + filename +".stl"
            plane.select_set(True)
            bpy.ops.export_mesh.stl(filepath = path,use_selection=True)

        for name in names:
            generate_nametag(name = name, f = font)
        return {'FINISHED'}

def menu_func(self, context):
    self.layout.operator(SimpleOperator.bl_idname, text=SimpleOperator.bl_label)

# Register and add to the "object" menu (required to also use F3 search "Simple Object Operator" for quick access)
def register():
    bpy.utils.register_class(SimpleOperator)
    bpy.types.VIEW3D_MT_object.append(menu_func)


def unregister():
    bpy.utils.unregister_class(SimpleOperator)
    bpy.types.VIEW3D_MT_object.remove(menu_func)


if __name__ == "__main__":
    register()

    # test call
    bpy.ops.object.generate_nametag()